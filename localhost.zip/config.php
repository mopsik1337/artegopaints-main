<?php
global$PAGE_AUTHOR;
$PAGE_AUTHOR = 'Milan Gorislavets';
$PAGE_TITLE = 'ARTEGOPAINTS.kz - Декоративные краски в Казахстане.';
$PAGE_URL = 'ARTEGOPAINTS.kz'
?>